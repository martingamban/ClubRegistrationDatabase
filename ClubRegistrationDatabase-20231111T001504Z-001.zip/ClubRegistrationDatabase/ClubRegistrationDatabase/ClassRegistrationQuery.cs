﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;
using System.Windows.Forms;
    
namespace ClubRegistrationDatabase
{
    class ClassRegistrationQuery
    {
        private SqlConnection sqlconnect;
        private SqlCommand sqlCommand;
        private SqlDataAdapter sqlAdapter;
        private SqlDataReader sqlReader;
        private string connectionString;

        public DataTable dataTable;
        public BindingSource bindingSource;

        public string _FirstName, _MiddleName, _LastName, _Gender, _Program;
        public int _Age;

        //CONNECTION
        public ClassRegistrationQuery()
        {
            connectionString = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Acer\source\repos\ClubRegistrationDatabase\ClubRegistrationDatabase\ClubDB.mdf;Integrated Security=True";
            sqlconnect = new SqlConnection(connectionString);
            dataTable = new DataTable();
            bindingSource = new BindingSource();
        }
        public bool DisplayList()
        {
            try
            {
                string ViewClubMembers = "SELECT StudentID, FirstName, MiddleName, LastName, Age, Gender, Program FROM ClubMembers";
                sqlAdapter = new SqlDataAdapter(ViewClubMembers, sqlconnect);
                dataTable.Clear();
                sqlAdapter.Fill(dataTable);
                bindingSource.DataSource = dataTable;
                return true;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
                return false;
            }
        }
        public bool RegisterStudent(int ID, long StudentID, string FirstName, string MiddleName, string LastName, int Age, string Gender, string Program)
        {
            try
            {
                sqlCommand = new SqlCommand("INSERT INTO ClubMembers VALUES (ID, StudentID, FirstName, MiddleName, LastName, Age, Gender, Program)", sqlconnect);
                sqlCommand.Parameters.Add("ID", SqlDbType.Int).Value = ID;
                sqlCommand.Parameters.Add("StudentID", SqlDbType.Int).Value = StudentID;
                sqlCommand.Parameters.Add("FirstName", SqlDbType.VarChar).Value = FirstName;
                sqlCommand.Parameters.Add("MiddleName", SqlDbType.VarChar).Value = MiddleName;
                sqlCommand.Parameters.Add("LastName", SqlDbType.VarChar).Value = MiddleName;
                sqlCommand.Parameters.Add("Age", SqlDbType.Int).Value = Age;
                sqlCommand.Parameters.Add("Gender", SqlDbType.VarChar).Value = Gender;
                sqlCommand.Parameters.Add("Program", SqlDbType.VarChar).Value = Program;

                sqlconnect.Open();
                sqlCommand.ExecuteNonQuery();
                sqlconnect.Close();
                return true;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
                return false;
            }
        }

        public bool UpdateClubMember(string FirstName, string MiddleName, string LastName, int Age, string Gender, string Program)
        {
            try
            {
                sqlconnect.Open();
                sqlCommand.CommandText = "UPDATE DemoDB SET LastName = @lname, FirstName = @fname, MiddleName = @mname, Age = @age, Gender = @gender, Program = @program, WHERE StudentId = @sId";

                sqlCommand.Parameters.AddWithValue("@FirstName", FirstName);
                sqlCommand.Parameters.AddWithValue("@MiddleName", MiddleName);
                sqlCommand.Parameters.AddWithValue("@LastName", LastName);
                sqlCommand.Parameters.AddWithValue("@Age", Age);
                sqlCommand.Parameters.AddWithValue("@Gender", Gender);
                sqlCommand.Parameters.AddWithValue("@Program", Program);

                sqlCommand.ExecuteNonQuery();
                sqlconnect.Close();
                MessageBox.Show("Updated Successfully", "Saved", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return true;

            }
            catch (Exception ex)
            {

                Console.WriteLine("Error : " + ex.Message);
                return false;
            }
        }
    }
}
