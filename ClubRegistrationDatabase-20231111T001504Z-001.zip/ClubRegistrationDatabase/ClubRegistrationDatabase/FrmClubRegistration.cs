﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace ClubRegistrationDatabase
{
    public partial class FrmClubRegistration : Form
    {
        private ClassRegistrationQuery clubRegistrationQuery;
        private int ID, Age, Count;
        private string FirstName, MiddleName, LastName, Gender, Program;

        private SqlCommand sqlCommand;

        private long StudentId;

        //CONNECTION
        public FrmClubRegistration()
        {
            InitializeComponent();

            if (sqlconnection.State == ConnectionState.Open)
            {
                sqlconnection.Close();
            }
            sqlconnection.Open();
            RefreshListOfMembers();
        }

        SqlConnection sqlconnection = new SqlConnection("Data Source=LAPTOP-M57NG0RF\\MSSQLSERVER01;Initial Catalog=ClubDB;Integrated Security=True");

        private void btnRegister_Click(object sender, EventArgs e)
        {
            //InputData();
            //clubRegistrationQuery.RegisterStudent(ID, StudentId, FirstName, MiddleName, LastName, Age, Gender, Program);
            RegisterStudent();
            RefreshListOfMembers();
            ClearInput();
        }

        private void FrmClubRegistration_Load(object sender, EventArgs e)
        {
            clubRegistrationQuery = new ClassRegistrationQuery();
            RefreshListOfMembers();
        }

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            RefreshListOfMembers();
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            FrmUpdateMember update = new FrmUpdateMember();
            update.Show();
        }
        public void RegisterStudent()
        {
            try
            {
                String query = "INSERT INTO ClubMembers VALUES ('" + txtStudentID.Text + "','" + txtFirstName.Text + "','" + txtMiddleName.Text + "','" + txtLastName.Text + "','" + txtAge.Text + "','" + cbGender.Text + "','" + cbProgram.Text + "')";
                SqlDataAdapter sda = new SqlDataAdapter(query, sqlconnection);
                sda.SelectCommand.ExecuteNonQuery();

                MessageBox.Show("Register Successfully");
                RefreshListOfMembers();
                ClearInput();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }

        //DISPLAY DATA
        public bool RefreshListOfMembers()
        {
            //clubRegistrationQuery.DisplayList();
            //dtClubMembers.DataSource = clubRegistrationQuery.bindingSource;
            try
            {
                SqlCommand cmd = sqlconnection.CreateCommand();
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = "SELECT StudentID, FirstName, MiddleName, LastName, Age, Gender, Program FROM ClubMembers";
                cmd.ExecuteNonQuery();

                DataTable dt = new DataTable();
                SqlDataAdapter sda = new SqlDataAdapter(cmd);
                sda.Fill(dt);
                dtClubMembers.DataSource = dt;
                return true;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
                return false;
            }
        }
        public void InputData()
        {
            StudentId = Convert.ToInt32(txtStudentID.Text);
            FirstName = txtFirstName.Text;
            MiddleName = txtMiddleName.Text;
            LastName = txtLastName.Text;
            Age = Convert.ToInt32(txtAge.Text);
            Gender = cbGender.Text;
            Program = cbGender.Text;
        }
        public void RegistrationID()
        {
            //return Count = Count + 1;
        }

        //CLEAR FIELDS
        public void ClearInput()
        {
            txtStudentID.Clear();
            txtFirstName.Clear();
            txtMiddleName.Clear();
            txtLastName.Clear();
            txtAge.Clear();
            cbGender.SelectedIndex = -1;
            cbProgram.SelectedIndex = -1;
        }
    }
}
