﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace ClubRegistrationDatabase
{
    public partial class FrmUpdateMember : Form
    {
        public FrmUpdateMember()
        {
            InitializeComponent();
        }
        //CONNECTION
        public static SqlConnection sqlconnection = new SqlConnection("Data Source=LAPTOP-M57NG0RF\\MSSQLSERVER01;Initial Catalog=ClubDB;Integrated Security=True");

        //DATABASE LINK TO COMBOBOX
        private void FrmUpdateMember_Load(object sender, EventArgs e)
        {
            try
            {
                sqlconnection.Open();
                SqlCommand cmd = sqlconnection.CreateCommand();
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = "SELECT * FROM ClubMembers";
                cmd.ExecuteNonQuery();
                DataTable dt = new DataTable();
                SqlDataAdapter sda = new SqlDataAdapter(cmd);
                sda.Fill(dt);
                foreach (DataRow dr in dt.Rows)
                {
                    cbStudentId.Items.Add(dr["StudentId"].ToString());
                }
                sqlconnection.Close();
            }catch(Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }
        private void cbStudentId_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                sqlconnection.Open();
                SqlCommand cmd = sqlconnection.CreateCommand();
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = "SELECT * FROM ClubMembers WHERE StudentId = '" + cbStudentId.SelectedItem.ToString() + "'";
                cmd.ExecuteNonQuery();
                DataTable dt = new DataTable();
                SqlDataAdapter sda = new SqlDataAdapter(cmd);
                sda.Fill(dt);
                foreach (DataRow dr in dt.Rows)
                {
                    txtLastName.Text = dr["LastName"].ToString();
                    txtFirstName.Text = dr["FirstName"].ToString();
                    txtMiddleName.Text = dr["MiddleName"].ToString();
                    txtAge.Text = dr["Age"].ToString();
                    cbGender.Text = dr["Gender"].ToString();
                    cbProgram.Text = dr["Program"].ToString();
                }
                sqlconnection.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }

        private void btnConfirm_Click(object sender, EventArgs e)
        {
            UpdateMember();
        }

        private bool UpdateMember()
        {
            try
            {
                sqlconnection.Open();
                String query = "UPDATE ClubMembers SET FirstName = '" + txtFirstName.Text + "',MiddleName = '" + txtMiddleName.Text + "',LastName = '" + txtLastName.Text + "',Age ='" + txtAge.Text + "',Gender = '" + cbGender.Text + "',Program ='" + cbProgram.Text + "'WHERE StudentId = '" + cbStudentId.Text + "'";
                SqlDataAdapter sda = new SqlDataAdapter(query, sqlconnection);
                sda.SelectCommand.ExecuteNonQuery();
                MessageBox.Show("Updated Successfully", "Saved", MessageBoxButtons.OK, MessageBoxIcon.Information);
                sqlconnection.Close();
                this.Hide();
                return true;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
                return false;
            }
        }
    }
}
